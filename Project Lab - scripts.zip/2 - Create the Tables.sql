-- Connect to the Database --

USE [AWSCustomers]



-- Customers Table --


CREATE TABLE [dbo].[Customers](
	[CustomerID] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](100) NOT NULL,
	[LastName] [varchar](100) NULL,
	[BirthDate] [date] NOT NULL,
	[MobileNumber] [varchar](20) NULL,
	[City] [varchar](100) NOT NULL,
	[Country] [varchar](100) NOT NULL,
 CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
) ON [PRIMARY]
)



-- Products Table --


CREATE TABLE [dbo].[Products](
	[ProductID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NOT NULL,
	[Description] [varchar](2000) NOT NULL,
	[WebUrl] [varchar](300) NOT NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[ProductID] ASC
) ON [PRIMARY]
)



-- Regions Table --

CREATE TABLE [dbo].[Regions](
	[RegionID] [smallint] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](40) NOT NULL,
	[RegionCode] [varchar](30) NOT NULL,
	[CountryCode] [char](3) NOT NULL,
 CONSTRAINT [PK_Regions] PRIMARY KEY CLUSTERED 
(
	[RegionID] ASC
) ON [PRIMARY]
)




-- Orders Table --

CREATE TABLE [dbo].[Orders](
	[OrderID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[ProductID] [int] NOT NULL,
	[RegionID] [smallint] NOT NULL,
	[OrderAmount] [money] NOT NULL,
	[OrderDate] [date] NOT NULL,
 CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED 
(
	[OrderID] ASC
) ON [PRIMARY]
)







