
-- Create a View --


CREATE VIEW dbo.SalesOrdersCustomer
AS
SELECT c.FirstName, c.LastName, c.Country, c.MobileNumber, SUM(o.OrderAmount) AS 'Sales Total'
FROM dbo.Customers c
JOIN dbo.Orders o
ON c.CustomerID = o.CustomerID
GROUP BY c.FirstName, c.LastName, c.Country, c.MobileNumber
HAVING SUM(o.OrderAmount) > 1500


-- Create a Procedure --


CREATE PROCEDURE dbo.SalesOrdersByCountry
@Country varchar(100)
AS
SELECT c.FirstName, c.LastName, c.Country, o.OrderAmount, o.OrderDate
FROM dbo.Customers c
JOIN dbo.Orders o
ON c.CustomerID = o.CustomerID
WHERE c.Country = @Country


Exec dbo.SalesOrdersByCountry @Country = 'United Kingdom' 

