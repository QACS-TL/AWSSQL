USE [master]

CREATE DATABASE AWSCustomers