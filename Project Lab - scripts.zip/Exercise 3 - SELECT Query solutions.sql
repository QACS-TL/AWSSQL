
-- SELECT Queries --



-- Task 1 --

SELECT *
FROM dbo.Customers
WHERE LastName LIKE 'J%'
ORDER BY LastName


-- Task 2 --

SELECT ProductID, OrderAmount AS 'Total Sales'
FROM dbo.Orders
WHERE ProductID IN (2, 4) AND OrderAmount > 1000
ORDER BY 'Total Sales' DESC


-- Task 3 --

SELECT c.FirstName, c.LastName, c.Country, o.OrderAmount, o.OrderDate
FROM dbo.Customers c
JOIN dbo.Orders o
ON c.CustomerID = o.CustomerID


-- Task 4 --


SELECT r.Name, COUNT(o.OrderID) AS 'Order Total'
FROM dbo.Regions r
JOIN dbo.Orders o
ON r.RegionID = o.RegionID
GROUP BY r.Name
ORDER BY 'Order Total' DESC


-- Task 5 --

SELECT c.FirstName, c.MobileNumber, c.Country, p.Name, o.OrderAmount, o.OrderDate
FROM dbo.Customers c
JOIN dbo.Orders o
ON o.CustomerID = c.CustomerID
JOIN dbo.Products p
ON o.ProductID = p.ProductID
ORDER BY OrderAmount DESC


-- Task 6 --

SELECT c.FirstName, c.LastName, c.Country, c.MobileNumber, SUM(o.OrderAmount) AS 'Sales Total'
FROM dbo.Customers c
JOIN dbo.Orders o
ON c.CustomerID = o.CustomerID
GROUP BY c.FirstName, c.LastName, c.Country, c.MobileNumber
HAVING SUM(o.OrderAmount) > 1500
ORDER BY 'Sales Total' DESC



