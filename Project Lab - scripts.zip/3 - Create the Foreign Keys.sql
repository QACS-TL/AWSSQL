-- Create the Foreign Keys --

USE [AWSCustomers]


-- Orders to Customers Table --

ALTER TABLE [dbo].[Orders]
WITH CHECK
ADD CONSTRAINT [FK_Orders_Customers] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])


-- Orders to Products Table --

ALTER TABLE [dbo].[Orders]
WITH CHECK
ADD CONSTRAINT [FK_Orders_Products] FOREIGN KEY([ProductID])
REFERENCES [dbo].[Products] ([ProductID])


-- Orders to Regions Table --

ALTER TABLE [dbo].[Orders]
WITH CHECK
ADD CONSTRAINT [FK_Orders_Regions] FOREIGN KEY([RegionID])
REFERENCES [dbo].[Regions] ([RegionID])

